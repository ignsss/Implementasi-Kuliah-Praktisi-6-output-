from shapely.geometry import Point

# Titik Koordinat (misal di Bengkulu)
lokasi_kantor = Point(102.2655, -3.7928)
lokasi_pelanggan = Point(102.2800, -3.8000)

# Menghitung jarak spasial
jarak = lokasi_kantor.distance(lokasi_pelanggan)

print("--- 3. Career and Competition in Industrial Era with GIS ---")
print(f"Titik Kantor: {lokasi_kantor}")
print(f"Titik Pelanggan: {lokasi_pelanggan}")
print(f"Jarak spasial (derajat desimal): {jarak:.4f}
")
