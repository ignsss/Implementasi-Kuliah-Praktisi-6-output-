import matplotlib.pyplot as plt

# Data Pendapatan Bulanan
kategori = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei']
pendapatan = [120, 150, 170, 200, 250]

print("--- 5. Human-Computer Interaction & Data Visualization ---")
print("Membuat grafik batang pendapatan...")

plt.figure(figsize=(6, 4))
plt.bar(kategori, pendapatan, color='skyblue')
plt.title('Grafik Pertumbuhan Pendapatan Bulanan')
plt.xlabel('Bulan')
plt.ylabel('Pendapatan (Juta Rp)')
plt.savefig('grafik_pendapatan.png') # Menyimpan grafik ke gambar
print("Grafik disimpan sebagai 'grafik_pendapatan.png'
")
