import time
from concurrent.futures import ThreadPoolExecutor

def proses_data_lokal(id_wilayah):
    time.sleep(1) # Simulasi komputasi berat
    return f"Wilayah {id_wilayah} selesai diproses."

if __name__ == '__main__':
    wilayah = [1, 2, 3, 4, 5]
    print("--- 2. Bridging Global Infrastructure with HPC ---")
    start_time = time.time()

    # Pemrosesan Paralel
    with ThreadPoolExecutor(max_workers=3) as executor:
        hasil = list(executor.map(proses_data_lokal, wilayah))

    for h in hasil:
        print(h)

    print(f"Total waktu komputasi paralel: {time.time() - start_time:.2f} detik
")
