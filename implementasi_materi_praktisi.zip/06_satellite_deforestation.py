import numpy as np

# Nilai indeks vegetasi (NDVI) sebelum & sesudah
tahap_awal = np.array([0.8, 0.75, 0.82])
tahap_akhir = np.array([0.8, 0.30, 0.81])

perubahan = tahap_awal - tahap_akhir
ambang_batas = 0.4 # Penurunan drastis = deforestasi

print("--- 6. Deforestation Alerts with Satellite Imagery and AI ---")
for i, status in enumerate(perubahan > ambang_batas):
    if status:
        print(f"PERINGATAN! Area ke-{i+1} terdeteksi deforestasi (penurunan vegetasi drastis).")
    else:
        print(f"Area ke-{i+1} aman / stabil.")
