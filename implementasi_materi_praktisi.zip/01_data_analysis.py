import pandas as pd

# 1. Data mentah (ada nilai yang kosong / NaN)
data = {
    'Produk': ['Laptop', 'Mouse', 'Keyboard', 'Monitor', 'Mouse'],
    'Harga': [15000000, 250000, None, 2000000, 250000] # Ada data kosong & duplikat
}

df = pd.DataFrame(data)
print("--- 1. Make Sense of Data with Analysis and AI ---")
print("Data Mentah:")
print(df)

# 2. Pembersihan & Analisis Deskriptif
df = df.drop_duplicates()
df['Harga'] = df['Harga'].fillna(df['Harga'].mean())

print("
Data Setelah Dibersihkan:")
print(df)
print(f"Rata-rata Harga Produk: Rp {df['Harga'].mean():,.0f}
")
