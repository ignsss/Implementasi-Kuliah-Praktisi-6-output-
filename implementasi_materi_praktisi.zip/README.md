# Contoh Implementasi Kode 6 Materi Praktisi Mengajar

Repository ini berisi skrip Python sederhana untuk 6 topik kuliah praktisi Informatika:

1. **`01_data_analysis.py`** - Make Sense of Data with Analysis and AI
2. **`02_hpc_simulation.py`** - Bridging Global Infrastructure to Address Local Challenge with HPC
3. **`03_gis_spatial.py`** - Career and Competition in Industrial Era with GIS
4. **`04_machine_learning.py`** - Introduction to Machine Learning
5. **`05_data_visualization.py`** - Human-Computer Interaction & Data Visualization
6. **`06_satellite_deforestation.py`** - Attributing Direct Drivers to Deforestation Alerts with Satellite Imagery and AI

## Cara Menjalankan
Install dependensi:
```bash
pip install pandas shapely scikit-learn matplotlib numpy
```
Jalankan file yang diinginkan, contoh:
```bash
python 01_data_analysis.py
```
