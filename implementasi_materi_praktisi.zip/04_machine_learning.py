from sklearn.neighbors import KNeighborsClassifier

# Data Latihan [Jam Belajar, Nilai Sebelum] -> [0: Gagal, 1: Lulus]
X_train = [[2, 60], [8, 85], [1, 40], [7, 90], [3, 50]]
y_train = [0, 1, 0, 1, 0]

# Melatih Model KNN
model = KNeighborsClassifier(n_neighbors=3)
model.fit(X_train, y_train)

# Prediksi Data Baru
data_baru = [[6, 80]]
prediksi = model.predict(data_baru)

print("--- 4. Introduction to Machine Learning ---")
print(f"Prediksi untuk data {data_baru}: {'Lulus (1)' if prediksi[0] == 1 else 'Tidak Lulus (0)'}
")
